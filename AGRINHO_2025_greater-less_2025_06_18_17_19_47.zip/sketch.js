let isDay = true; // Variável para controlar se é dia (true) ou noite (false)

function setup() {
  createCanvas(600, 400); // Cria uma tela de 600x400 pixels
  // Não precisamos carregar nada complexo por enquanto
}

function draw() {
  if (isDay) {
    drawDayScene();
  } else {
    drawNightScene();
  }
}

function mousePressed() {
  // Alterna entre dia e noite ao clicar
  isDay = !isDay; // Inverte o valor de isDay
}

function drawDayScene() {
  // Céu azul claro do dia
  background(135, 206, 235); // Cor: Light Sky Blue

  // Sol
  fill(255, 255, 0); // Amarelo vibrante
  noStroke();
  ellipse(width * 0.8, height * 0.2, 100, 100); // Posição superior direita

  // Grama / Chão
  fill(34, 139, 34); // Cor: Forest Green
  rect(0, height * 0.7, width, height * 0.3);

  // Nuvens
  fill(255, 255, 255, 200); // Branco com um pouco de transparência
  ellipse(width * 0.2, height * 0.15, 80, 50);
  ellipse(width * 0.3, height * 0.12, 70, 40);
  ellipse(width * 0.7, height * 0.1, 90, 60);

  // Texto indicativo
  fill(0); // Cor preta para o texto
  textSize(24);
  textAlign(CENTER, CENTER);
  text("É DIA!", width / 2, height / 2);
  textSize(14);
  text("Clique para virar NOITE", width / 2, height * 0.9);
}

function drawNightScene() {
  // Céu noturno escuro
  background(25, 25, 112); // Cor: Midnight Blue

  // Lua
  fill(200, 200, 200); // Cinza claro para a lua
  noStroke();
  ellipse(width * 0.2, height * 0.2, 90, 90);

  // Estrelas
  fill(255, 255, 255); // Branco para as estrelas
  for (let i = 0; i < 100; i++) {
    let x = random(width);
    let y = random(height * 0.6); // Estrelas aparecem na parte de cima do céu
    ellipse(x, y, random(1, 4), random(1, 4)); // Tamanhos variados
  }

  // Chão noturno (um pouco mais escuro)
  fill(50, 50, 50); // Cinza escuro para o chão
  rect(0, height * 0.7, width, height * 0.3);

  // Texto indicativo
  fill(255); // Cor branca para o texto
  textSize(24);
  textAlign(CENTER, CENTER);
  text("É NOITE!", width / 2, height / 2);
  textSize(14);
  text("Clique para virar DIA", width / 2, height * 0.9);
}